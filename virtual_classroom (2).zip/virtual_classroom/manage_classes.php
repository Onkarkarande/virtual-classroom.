<?php
include 'db.php';
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_class'])) {
    $name = $_POST['name'];
    $description = $_POST['description'];
    $stmt = $conn->prepare("INSERT INTO classes (name, description) VALUES (?, ?)");
    $stmt->bind_param("ss", $name, $description);
    if ($stmt->execute()) {
        echo "Class added successfully!";
    } else {
        echo "Error: " . $stmt->error;
    }
    $stmt->close();
}

$result = $conn->query("SELECT * FROM classes");
$classes = $result->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Classes</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: lightblue; }
        .container { max-width: 800px; margin: auto; }
        .form-container { background-color: white; padding: 20px; border-radius: 8px; box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); }
        .form-container input, .form-container button { width: 100%; padding: 10px; margin: 8px 0; border: 1px solid lightgray; border-radius: 4px; }
        .form-container button { background-color: green; color: white; border: none; cursor: pointer; }
        .form-container button:hover { background-color: darkgreen; }
        .class-list { margin-top: 20px; }
        .class-list ul { list-style-type: none; padding: 0; }
        .class-list li { margin-bottom: 10px; }
    </style>
</head>
<body>
    <div class="container">
        <div class="form-container">
            <h2>Add Class</h2>
            <form method="POST">
                Name: <input type="text" name="name" required><br>
                Description: <textarea name="description" required></textarea><br>
                <button type="submit" name="add_class">Add Class</button>
            </form>
        </div>

        <div class="class-list">
            <h2>Classes</h2>
            <ul>
                <?php foreach ($classes as $class): ?>
                    <li><?php echo htmlspecialchars($class['name']); ?> - <?php echo htmlspecialchars($class['description']); ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    </div>
</body>
</html>
