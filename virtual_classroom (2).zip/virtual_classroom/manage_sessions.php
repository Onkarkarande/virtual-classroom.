<?php
include 'db.php';
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}


if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_session'])) {
    $unit_id = $_POST['unit_id'];
    $name = $_POST['name'];
    $description = $_POST['description'];
    $stmt = $conn->prepare("INSERT INTO sessions (unit_id, name, description) VALUES (?, ?, ?)");
    $stmt->bind_param("iss", $unit_id, $name, $description);
    if ($stmt->execute()) {
        echo "Session added successfully!";
    } else {
        echo "Error: " . $stmt->error;
    }
    $stmt->close();
}

$result = $conn->query("SELECT * FROM units");
$units = $result->fetch_all(MYSQLI_ASSOC);


$result = $conn->query("SELECT * FROM sessions");
$sessions = $result->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Sessions</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: lightblue; }
        .container { max-width: 800px; margin: auto; }
        .form-container { background-color: white; padding: 20px; border-radius: 8px; box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); }
        .form-container input, .form-container select, .form-container button { width: 100%; padding: 10px; margin: 8px 0; border: 1px solid lightgray; border-radius: 4px; }
        .form-container button { background-color: green; color: white; border: none; cursor: pointer; }
        .form-container button:hover { background-color: darkgreen; }
        .session-list { margin-top: 20px; }
        .session-list ul { list-style-type: none; padding: 0; }
        .session-list li { margin-bottom: 10px; }
    </style>
</head>
<body>
    <div class="container">
        <div class="form-container">
            <h2>Add Session</h2>
            <form method="POST">
                Unit:
                <select name="unit_id" required>
                    <?php foreach ($units as $unit): ?>
                        <option value="<?php echo htmlspecialchars($unit['id']); ?>">
                            <?php echo htmlspecialchars($unit['name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select><br>
                Name: <input type="text" name="name" required><br>
                Description: <textarea name="description" required></textarea><br>
                <button type="submit" name="add_session">Add Session</button>
            </form>
        </div>

        <div class="session-list">
            <h2>Sessions</h2>
            <ul>
                <?php foreach ($sessions as $session): ?>
                    <li><?php echo htmlspecialchars($session['name']); ?> - <?php echo htmlspecialchars($session['description']); ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    </div>
</body>
</html>
