<?php
include 'db.php';
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}


if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_lecture'])) {
    $session_id = $_POST['session_id'];
    $title = $_POST['title'];
    $content = $_POST['content'];
    $stmt = $conn->prepare("INSERT INTO lectures (session_id, title, content) VALUES (?, ?, ?)");
    $stmt->bind_param("iss", $session_id, $title, $content);
    if ($stmt->execute()) {
        echo "Lecture added successfully!";
    } else {
        echo "Error: " . $stmt->error;
    }
    $stmt->close();
}


$result = $conn->query("SELECT * FROM sessions");
$sessions = $result->fetch_all(MYSQLI_ASSOC);


$result = $conn->query("SELECT * FROM lectures");
$lectures = $result->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Lectures</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: lightblue; }
        .container { max-width: 800px; margin: auto; }
        .form-container { background-color: white; padding: 20px; border-radius: 8px; box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); }
        .form-container input, .form-container textarea, .form-container select, .form-container button { width: 100%; padding: 10px; margin: 8px 0; border: 1px solid lightgray; border-radius: 4px; }
        .form-container button { background-color: green; color: white; border: none; cursor: pointer; }
        .form-container button:hover { background-color: darkgreen; }
        .lecture-list { margin-top: 20px; }
        .lecture-list ul { list-style-type: none; padding: 0; }
        .lecture-list li { margin-bottom: 10px; }
    </style>
</head>
<body>
    <div class="container">
        <div class="form-container">
            <h2>Add Lecture</h2>
            <form method="POST">
                Session:
                <select name="session_id" required>
                    <?php foreach ($sessions as $session): ?>
                        <option value="<?php echo htmlspecialchars($session['id']); ?>">
                            <?php echo htmlspecialchars($session['name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select><br>
                Title: <input type="text" name="title" required><br>
                Content: <textarea name="content" required></textarea><br>
                <button type="submit" name="add_lecture">Add Lecture</button>
            </form>
        </div>

        <div class="lecture-list">
            <h2>Lectures</h2>
            <ul>
                <?php foreach ($lectures as $lecture): ?>
                    <li><?php echo htmlspecialchars($lecture['title']); ?> - <?php echo htmlspecialchars($lecture['content']); ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    </div>
</body>
</html>
