<?php
include 'db.php';
session_start();


$result = $conn->query("SELECT * FROM lectures");
$lectures = $result->fetch_all(MYSQLI_ASSOC);

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_comment'])) {
    $lecture_id = $_POST['lecture_id'];
    $user_id = $_SESSION['user_id'];
    $parent_id = isset($_POST['parent_id']) ? $_POST['parent_id'] : null;
    $comment = $_POST['comment'];

    $stmt = $conn->prepare("INSERT INTO comments (lecture_id, user_id, parent_id, comment) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("iiss", $lecture_id, $user_id, $parent_id, $comment);
    if ($stmt->execute()) {
        echo "Comment added successfully!";
    } else {
        echo "Error: " . $stmt->error;
    }
    $stmt->close();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Comments</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: lightblue; }
        .container { max-width: 800px; margin: auto; }
        .form-container { background-color: white; padding: 20px; border-radius: 8px; box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); }
        .form-container input, .form-container textarea, .form-container select, .form-container button { width: 100%; padding: 10px; margin: 8px 0; border: 1px solid lightgray; border-radius: 4px; }
        .form-container button { background-color: green; color: white; border: none; cursor: pointer; }
        .form-container button:hover { background-color: darkgreen; }
        .comment-list { margin-top: 20px; }
        .comment-list ul { list-style-type: none; padding: 0; }
        .comment-list li { margin-bottom: 10px; }
    </style>
</head>
<body>
    <div class="container">
        <div class="form-container">
            <h2>Add Comment</h2>
            <form method="POST">
                Lecture:
                <select name="lecture_id" required>
                    <?php foreach ($lectures as $lecture): ?>
                        <option value="<?php echo htmlspecialchars($lecture['id']); ?>">
                            <?php echo htmlspecialchars($lecture['title']); ?>
                        </option>
                    <?php endforeach; ?>
                </select><br>
                Parent Comment ID (if any): <input type="number" name="parent_id"><br>
                Comment: <textarea name="comment" required></textarea><br>
                <button type="submit" name="add_comment">Add Comment</button>
            </form>
        </div>
    </div>
</body>
</html>
