<?php
include 'db.php';
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'student') {
    header("Location: login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['enroll'])) {
    $class_id = $_POST['class_id'];
    $user_id = $_SESSION['user_id'];

    $stmt = $conn->prepare("INSERT INTO enrollments (user_id, class_id) VALUES (?, ?)");
    $stmt->bind_param("ii", $user_id, $class_id);
    if ($stmt->execute()) {
        echo "Enrollment successful!";
    } else {
        echo "Error: " . $stmt->error;
    }
    $stmt->close();
}


$result = $conn->query("SELECT * FROM classes");
$classes = $result->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Enroll in Class</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: lightblue; }
        .container { max-width: 800px; margin: auto; }
        .form-container { background-color: white; padding: 20px; border-radius: 8px; box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); }
        .form-container select, .form-container button { width: 100%; padding: 10px; margin: 8px 0; border: 1px solid lightgray; border-radius: 4px; }
        .form-container button { background-color: green; color: white; border: none; cursor: pointer; }
        .form-container button:hover { background-color: darkgreen; }
    </style>
</head>
<body>
    <div class="container">
        <div class="form-container">
            <h2>Enroll in Class</h2>
            <form method="POST">
                Class:
                <select name="class_id" required>
                    <?php foreach ($classes as $class): ?>
                        <option value="<?php echo htmlspecialchars($class['id']); ?>">
                            <?php echo htmlspecialchars($class['name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select><br>
                <button type="submit" name="enroll">Enroll</button>
            </form>
        </div>
    </div>
</body>
</html>
