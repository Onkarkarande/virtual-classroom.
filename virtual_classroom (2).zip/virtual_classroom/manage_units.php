<?php
include 'db.php';
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}


if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_unit'])) {
    $class_id = $_POST['class_id'];
    $name = $_POST['name'];
    $description = $_POST['description'];
    $stmt = $conn->prepare("INSERT INTO units (class_id, name, description) VALUES (?, ?, ?)");
    $stmt->bind_param("iss", $class_id, $name, $description);
    if ($stmt->execute()) {
        echo "Unit added successfully!";
    } else {
        echo "Error: " . $stmt->error;
    }
    $stmt->close();
}


$result = $conn->query("SELECT * FROM classes");
$classes = $result->fetch_all(MYSQLI_ASSOC);

$result = $conn->query("SELECT * FROM units");
$units = $result->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Units</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: lightblue; }
        .container { max-width: 800px; margin: auto; }
        .form-container { background-color: white; padding: 20px; border-radius: 8px; box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); }
        .form-container input, .form-container select, .form-container button { width: 100%; padding: 10px; margin: 8px 0; border: 1px solid lightgray; border-radius: 4px; }
        .form-container button { background-color: green; color: white; border: none; cursor: pointer; }
        .form-container button:hover { background-color: darkgreen; }
        .unit-list { margin-top: 20px; }
        .unit-list ul { list-style-type: none; padding: 0; }
        .unit-list li { margin-bottom: 10px; }
    </style>
</head>
<body>
    <div class="container">
        <div class="form-container">
            <h2>Add Unit</h2>
            <form method="POST">
                Class:
                <select name="class_id" required>
                    <?php foreach ($classes as $class): ?>
                        <option value="<?php echo htmlspecialchars($class['id']); ?>">
                            <?php echo htmlspecialchars($class['name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select><br>
                Name: <input type="text" name="name" required><br>
                Description: <textarea name="description" required></textarea><br>
                <button type="submit" name="add_unit">Add Unit</button>
            </form>
        </div>

        <div class="unit-list">
            <h2>Units</h2>
            <ul>
                <?php foreach ($units as $unit): ?>
                    <li><?php echo htmlspecialchars($unit['name']); ?> - <?php echo htmlspecialchars($unit['description']); ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    </div>
</body>
</html>
