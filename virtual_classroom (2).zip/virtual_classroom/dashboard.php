<?php
include 'db.php';
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}


$result = $conn->query("SELECT * FROM classes");
$classes = $result->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Dashboard</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: lightblue; }
        .container { max-width: 800px; margin: auto; }
        .class-list { background-color: white; padding: 20px; border-radius: 8px; box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); margin-bottom: 20px; }
        .class-list ul { list-style-type: none; padding: 0; }
        .class-list li { margin-bottom: 10px; }
    </style>
</head>
<body>
    <div class="container">
        <h1>Welcome to the Dashboard</h1>
        <div class="class-list">
            <h2>Classes</h2>
            <ul>
                <?php foreach ($classes as $class): ?>
                    <li><?php echo htmlspecialchars($class['name']); ?> - <?php echo htmlspecialchars($class['description']); ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    </div>
</body>
</html>
